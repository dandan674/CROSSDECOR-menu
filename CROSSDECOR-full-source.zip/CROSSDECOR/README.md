# CROSSDECOR — Android64 Geode mod (visual menu prototype)

This project adds a small CROSSDECOR button to the Geometry Dash level editor. Pressing it toggles a visual panel that uses the supplied CROSSDECOR artwork.

## Included

- `src/main.cpp` — editor hook, floating open button, and visual panel
- `resources/crossdecor-logo.png` — CROSSDECOR logo
- `resources/crossdecor-background.jpg` — black wallpaper with white crosses
- `resources/color-wheels.png` — color wheel / grayscale artwork
- `resources/touch-button.png` — button artwork
- `resources/Cyberpunk.ttf` — supplied font reference (not loaded as a custom in-game font yet)
- `.github/workflows/main.yml` — GitHub Actions Android64 build workflow
- `CMakeLists.txt`, `mod.json` — Geode project configuration

## Build

1. Upload the contents of this folder to your GitHub repository.
2. In `mod.json`, replace `yourname.crossdecor` with a unique Geode mod ID and `YourName` with your developer name if desired.
3. Open **Actions** and run **Build CROSSDECOR Android64**.
4. Download the `CROSSDECOR-Android64` artifact from a successful workflow run. It should contain the `.geode` package.

## Current scope

This version is only a **visual menu prototype**. The open/close button is functional, but the menu tiles (SINGLE OBJECT, MULTI SELECT, FULL LEVEL, STYLES, COLORS, GLOW) are labels/placeholders and do not modify objects or levels. The custom font is included as an asset but not yet registered as an in-game font.

The code has not been compiled against your exact Geode setup in this environment. Run the GitHub Actions workflow and use its first compiler error, if any, to make the next correction. Test on a copy of a level.
