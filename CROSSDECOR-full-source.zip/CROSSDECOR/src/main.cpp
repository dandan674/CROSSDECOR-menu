#include <Geode/Geode.hpp>
#include <Geode/modify/EditLevelLayer.hpp>

using namespace geode::prelude;

namespace {
    // Load a texture from this mod's resources directory.
    CCSprite* crossDecorSprite(char const* file) {
        auto path = Mod::get()->getResourcesDir() / file;
        return CCSprite::create(path.string().c_str());
    }

    void fitSprite(CCSprite* sprite, float width, float height) {
        if (!sprite) return;
        auto size = sprite->getContentSize();
        if (size.width <= 0.f || size.height <= 0.f) return;
        sprite->setScaleX(width / size.width);
        sprite->setScaleY(height / size.height);
    }
}

// CROSSDECOR v0.1.0: visual menu prototype only.
// Menu items are intentionally decorative and do not modify level objects yet.
class $modify(CrossDecorEditLevelLayer, EditLevelLayer) {
    bool init(GJGameLevel* level) {
        if (!EditLevelLayer::init(level))
            return false;

        auto winSize = CCDirector::sharedDirector()->getWinSize();

        // Floating button that opens/closes the CROSSDECOR panel.
        auto menu = CCMenu::create();
        if (!menu) return true;
        menu->setID("crossdecor-touch-menu");
        menu->setPosition(CCPointZero);

        auto normal = crossDecorSprite("touch-button.png");
        auto selected = crossDecorSprite("touch-button.png");
        CCMenuItem* openButton = nullptr;
        if (normal && selected) {
            fitSprite(normal, 48.f, 48.f);
            fitSprite(selected, 48.f, 48.f);
            openButton = CCMenuItemSprite::create(
                normal, selected, this,
                menu_selector(CrossDecorEditLevelLayer::onCrossDecorToggle)
            );
        } else {
            auto label = CCLabelBMFont::create("CD", "bigFont.fnt");
            if (label) {
                openButton = CCMenuItemLabel::create(
                    label, this,
                    menu_selector(CrossDecorEditLevelLayer::onCrossDecorToggle)
                );
            }
        }

        if (openButton) {
            openButton->setID("crossdecor-open-button");
            openButton->setPosition({winSize.width - 36.f, winSize.height * 0.55f});
            menu->addChild(openButton);
        }
        this->addChild(menu, 1000);

        // Panel uses the supplied artwork. All feature tiles are visual placeholders.
        auto panel = CCNode::create();
        if (!panel) return true;
        panel->setID("crossdecor-panel");
        panel->setVisible(false);
        panel->setPosition(CCPointZero);

        auto background = crossDecorSprite("crossdecor-background.jpg");
        if (background) {
            fitSprite(background, 360.f, 228.f);
            background->setPosition({winSize.width / 2.f, winSize.height / 2.f});
            panel->addChild(background, 0);
        } else {
            auto shade = CCLayerColor::create({12, 12, 18, 245}, 360.f, 228.f);
            shade->setPosition({winSize.width / 2.f - 180.f, winSize.height / 2.f - 114.f});
            panel->addChild(shade, 0);
        }

        auto logo = crossDecorSprite("crossdecor-logo.png");
        if (logo) {
            fitSprite(logo, 185.f, 54.f);
            logo->setPosition({winSize.width / 2.f, winSize.height / 2.f + 72.f});
            panel->addChild(logo, 2);
        } else {
            auto title = CCLabelBMFont::create("CROSSDECOR", "bigFont.fnt");
            if (title) {
                title->setScale(0.65f);
                title->setPosition({winSize.width / 2.f, winSize.height / 2.f + 72.f});
                panel->addChild(title, 2);
            }
        }

        auto wheels = crossDecorSprite("color-wheels.png");
        if (wheels) {
            fitSprite(wheels, 112.f, 82.f);
            wheels->setPosition({winSize.width / 2.f - 100.f, winSize.height / 2.f - 8.f});
            panel->addChild(wheels, 2);
        }

        // Decorative labels only. Their actions will be implemented later.
        char const* labels[] = {"SINGLE OBJECT", "MULTI SELECT", "FULL LEVEL", "STYLES", "COLORS", "GLOW"};
        for (int i = 0; i < 6; ++i) {
            auto tile = CCLabelBMFont::create(labels[i], "bigFont.fnt");
            if (!tile) continue;
            tile->setScale(0.34f);
            float x = winSize.width / 2.f + 42.f + (i % 2) * 83.f;
            float y = winSize.height / 2.f + 22.f - (i / 2) * 34.f;
            tile->setPosition({x, y});
            panel->addChild(tile, 3);
        }

        auto closeLabel = CCLabelBMFont::create("X", "bigFont.fnt");
        if (closeLabel) {
            auto closeButton = CCMenuItemLabel::create(
                closeLabel, this,
                menu_selector(CrossDecorEditLevelLayer::onCrossDecorToggle)
            );
            if (closeButton) {
                closeButton->setID("crossdecor-close-button");
                closeButton->setScale(0.65f);
                closeButton->setPosition({winSize.width / 2.f + 162.f, winSize.height / 2.f + 95.f});
                auto panelMenu = CCMenu::create();
                if (panelMenu) {
                    panelMenu->setPosition(CCPointZero);
                    panelMenu->addChild(closeButton);
                    panel->addChild(panelMenu, 5);
                }
            }
        }

        auto note = CCLabelBMFont::create("VISUAL PREVIEW - TOOLS NOT ACTIVE", "bigFont.fnt");
        if (note) {
            note->setScale(0.28f);
            note->setPosition({winSize.width / 2.f, winSize.height / 2.f - 94.f});
            panel->addChild(note, 3);
        }

        this->addChild(panel, 1001);
        return true;
    }

    void onCrossDecorToggle(CCObject*) {
        auto panel = this->getChildByID("crossdecor-panel");
        if (panel)
            panel->setVisible(!panel->isVisible());
    }
};
